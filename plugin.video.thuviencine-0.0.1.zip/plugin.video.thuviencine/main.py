# -*- coding: utf-8 -*-
# Module: default
# Author: CineTV
# Created on: 2026-05-21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib.parse import (
    urlencode,
    parse_qsl,
    urlparse
)
import requests
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
import json
# import simplecache
# import threading
# import re
from concurrent.futures import ThreadPoolExecutor, as_completed

# _cache = simplecache.SimpleCache()
# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

APP_ID = 'plugin.video.thuviencine'
addon = xbmcaddon.Addon()
HOME_PAGE = addon.getSetting(
    'home_page'
).strip() or 'https://thuviencine.live'
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/59.0.3071.109 Chrome/59.0.3071.109 Safari/537.36'
HEADERS = {'User-Agent': UA}
UA_FSHARE_API = 'thuviencine-FSWXQQ'
HEADERS_FSHARE_API = {'User-Agent': UA_FSHARE_API}
APP_KEY_FSHARE_API = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'

LOG_PREFIX = '[{}]'.format(
    addon.getAddonInfo('id')
)

def addon_log(message, level=xbmc.LOGINFO):
    """
    Write Kodi addon log.
    """

    xbmc.log(
        '{} {}'.format(
            LOG_PREFIX,
            message
        ),
        level
    )

def ensure_fshare_settings():
    """
    Ensure Fshare account settings exist.
    """

    username = addon.getSetting(
        'username'
    ).strip()

    password = addon.getSetting(
        'password'
    ).strip()

    if username and password:
        return True

    # xbmcgui.Dialog().ok(
    #     'ThuVienCine',
    #     'Vui lòng nhập tài khoản Fshare'
    # )

    addon.openSettings()

    # Reload settings after settings dialog closed
    username = addon.getSetting(
        'username'
    ).strip()

    password = addon.getSetting(
        'password'
    ).strip()

    return bool(username and password)

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def get_categories():
    """
    Get movie categories from website.
    """

    response = requests.get(HOME_PAGE, headers=HEADERS)

    if response.status_code != 200:
        addon_log.log(
            'Request failed: {}'.format(response.status_code),
            xbmc.LOGERROR
        )
        return []

    soup = BeautifulSoup(response.text, 'html.parser')

    categories = []

    # Extra menu
    categories.append({
        'name': 'Tìm Kiếm',
        'url': 'search'
    })

    categories.append({
        'name': 'Phim Hot',
        'url': '/top/'
    })

    categories.append({
        'name': 'Tất Cả',
        'url': '/home-page/'
    })

    categories.append({
        'name': 'Phim Lẻ',
        'url': '/movies/'
    })

    categories.append({
        'name': 'Phim Bộ',
        'url': '/tv-series/'
    })

    # Find category menu
    category_menu = soup.select_one(
        'li.genre-filter ul.dropdown-menu-large'
    )

    if category_menu:

        # Find all links inside category menu
        for a in category_menu.find_all('a'):

            name = a.get_text(strip=True)
            url = a.get('href', '')

            # Skip empty link
            if not url:
                continue

            # Convert absolute url to relative url
            url = url.replace(HOME_PAGE, '')

            categories.append({
                'name': name,
                'url': url
            })

    return categories

def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['name'])

        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(category['name'])
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category['url'])
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)

#TODO: Needed or not?
def get_plot(data_url, vid):
    ajax = requests.get(data_url, headers=HEADERS)
    p = BeautifulSoup(ajax.text, 'html.parser', from_encoding='utf-8')
    vid['plot'] = p.find(class_='f-desc').string

def get_videos(category, page=1, query=''):
    """
    Get video list from ThuVienCine.

    :param category: Genre name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """

    # Search
    if category == 'search':

        # Ask keyword only first page
        if not query:

            kb = xbmc.Keyboard(
                '',
                'Nhập từ khóa tìm kiếm'
            )

            kb.doModal()

            if not kb.isConfirmed():
                return []

            query = kb.getText().strip()

            if not query:
                return []

        query_encoded = query.replace(' ', '+')

        if page == 1:
            url = HOME_PAGE + '/?s={}'.format(
                query_encoded
            )
        else:
            url = HOME_PAGE + '/page/{}/?s={}'.format(
                page,
                query_encoded
            )

    # Home page
    elif category == '/home-page/':

        if page == 1:
            url = HOME_PAGE
        else:
            url = HOME_PAGE + '/page/{}/'.format(page)

    # Normal category
    else:

        # Normalize category path
        category = '/' + category.strip('/') + '/'

        if page == 1:
            url = HOME_PAGE + category
        else:
            url = HOME_PAGE + category + 'page/{}/'.format(page)

    response = requests.get(
        url,
        headers=HEADERS
    )

    if response.status_code != 200:
        addon_log.log(
            'Get videos failed: {}'.format(response.status_code),
            xbmc.LOGERROR
        )
        return [{
            'name': 'Hết',
            'end': True
        }]

    bs = BeautifulSoup(
        response.text,
        'html.parser'
    )

    # Find movie items
    items = bs.select(
        'div[id^="post-"].item'
    )

    if not items:
        return [{
            'name': 'Hết',
            'end': True
        }]

    videos = []

    added = set()

    for item in items:

        a = item.select_one(
            'a[rel="bookmark"]'
        )

        if not a:
            continue

        href = a.get('href')

        if not href:
            continue

        # Skip duplicate
        if href in added:
            continue

        added.add(href)

        # Get numeric post id
        post_id = ''

        item_id = item.get('id', '')

        if item_id.startswith('post-'):
            post_id = item_id.replace('post-', '')

        if not post_id:
            continue

        # Title
        title = a.get('title')

        img = item.find('img')

        thumb = ''

        if img:

            thumb = (
                img.get('data-original')
                or img.get('data-src')
                or img.get('src')
                or ''
            )

        # Fallback title
        if not title:

            if img:
                title = img.get('alt', '')

            if not title:
                title = a.get_text(strip=True)

        if not title:
            continue

        # Default metadata
        plot = ''
        rating = 0.0
        year = 0
        genre = ''
        runtime = ''

        # Plot
        description = item.select_one(
            '.movie-description'
        )

        if description:

            plot = description.get_text(
                strip=True
            )

        # IMDb rating
        imdb = item.select_one(
            '.imdb-rating'
        )

        if imdb:

            imdb_text = imdb.get_text(
                strip=True
            )

            imdb_text = (
                imdb_text
                .replace('N/A', '')
                .replace('/10', '')
                .replace('IMDb', '')
                .replace('★', '')
                .strip()
            )

            try:

                rating = float(imdb_text)

            except:
                pass

        # Year
        movie_date = item.select_one(
            '.movie-date'
        )

        if movie_date:

            try:

                year = int(
                    movie_date.get_text(
                        strip=True
                    )
                )

            except:
                pass

        # Genre
        genre_el = item.select_one(
            '.genre'
        )

        if genre_el:

            genre = genre_el.get_text(
                strip=True
            )

        # Runtime
        runtime_el = item.select_one(
            '.runtime'
        )

        if runtime_el:

            runtime = runtime_el.get_text(
                strip=True
            )

        # Quality
        quality = ''

        quality_el = item.select_one(
            '.item-quality'
        )

        if quality_el:

            quality = quality_el.get_text(
                strip=True
            )

        videos.append({
            'name': title,
            'id': post_id,
            'thumb': thumb,
            'fanart': thumb,
            'plot': plot,
            'rating': rating,
            'year': year,
            'genre': genre,
            'runtime': runtime,
            'quality': quality
        })

    # No movie found
    if not videos:
        return [{
            'name': 'Hết',
            'end': True
        }]

    # Add next page
    videos.append({
        'name': 'Next Page',
        'category': category,
        'page': page + 1,
        'query': query,
        'next_page': True
    })

    return videos

def list_videos(category, page=1, query=''):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """

    videos = get_videos(category, page, query)

    for video in videos:

        label = video['name']

        list_item = xbmcgui.ListItem(
            label=label
        )

        # End item
        if video.get('end'):

            xbmcplugin.addDirectoryItem(
                handle=_handle,
                url='',
                listitem=list_item,
                isFolder=False
            )

            continue

        # Next page
        if video.get('next_page'):

            url = get_url(
                action='listing',
                category=video['category'],
                page=video['page'],
                query=video.get('query', '')
            )

            xbmcplugin.addDirectoryItem(
                handle=_handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )

            continue

        info_tag = list_item.getVideoInfoTag()

        info_tag.setTitle(
            video['name']
        )

        # Plot
        if video.get('plot'):

            info_tag.setPlot(
                video['plot']
            )

        # IMDb rating
        if video.get('rating'):

            info_tag.setRating(
                video['rating']
            )

        # Year
        if video.get('year'):

            info_tag.setYear(
                video['year']
            )

        # Media type
        info_tag.setMediaType(
            'movie'
        )

        # Genre
        if video.get('genre'):

            info_tag.setGenres([
                video['genre']
            ])

        # Runtime
        runtime = video.get(
            'runtime',
            ''
        )

        if runtime and runtime != 'N/A':

            try:

                runtime_minutes = int(
                    runtime.replace('min', '').strip()
                )

                info_tag.setDuration(
                    runtime_minutes * 60
                )

            except:
                pass

        plot = video.get(
            'plot',
            ''
        )

        if video.get('quality'):

            plot = '[B]Chất lượng:[/B] {}\n\n{}'.format(
                video['quality'],
                plot
            )

        list_item.setInfo('video', {
            'title': video['name'],
            'plot': plot,
            'rating': video.get('rating', 0),
            'year': video.get('year', 0),
            'genre': video.get('genre', ''),
            'mediatype': 'movie'
        })

        thumb = video.get('thumb', '')

        parts = thumb.split('/')

        if len(parts) > 5:
            parts[5] = 'original'

        fanart = '/'.join(parts)

        list_item.setArt({
            'thumb': fanart,
            'icon': '',
            'fanart': ''
        })

        url = get_url(
            action='listing',
            video=video.get('id', '')
        )

        xbmcplugin.addDirectoryItem(
            handle=_handle,
            url=url,
            listitem=list_item,
            isFolder=True
        )

    xbmcplugin.setContent(
        _handle,
        'movies'
    )

    xbmcplugin.endOfDirectory(
        _handle
    )

def get_fshare_linkcode(url):
    """
    Extract Fshare linkcode from URL.
    """

    path = urlparse(url).path

    parts = [p for p in path.split('/') if p]

    if not parts:
        return None

    return parts[-1]

def call_fshare_folder_api(linkcode):
    """
    Call Fshare folder API.
    """

    api_url = (
        'https://www.fshare.vn/api/v3/files/folder'
        '?linkcode={}&sort=type,name'
    ).format(linkcode)

    response = requests.get(
        api_url,
        headers=HEADERS,
        timeout=10
    )

    response.raise_for_status()

    return response.json()

def fetch_fshare_info(index, current):
    """
    Fetch folder info from Fshare API.
    """

    url = current.get('url', '')

    linkcode = get_fshare_linkcode(url)

    if not linkcode:
        return index, None

    try:

        data = call_fshare_folder_api(linkcode)

        current_info = data.get('current', {})

        return index, {
            'current.name': current_info.get('name'),
            'current.type': current_info.get('type'),
            'current.size': current_info.get('size')
        }

    except Exception as e:

        addon_log.log(
            'Fshare API error: {}'.format(e),
            xbmc.LOGERROR
        )

        return index, None

def get_links(post_id):
    """
    Get download links from download page.

    :param post_id: Movie post id
    :type post_id: str
    :return: download links
    :rtype: dict
    """

    url = HOME_PAGE + '/download?id={}'.format(
        post_id
    )

    response = requests.get(
        url,
        headers=HEADERS
    )

    if response.status_code != 200:
        addon_log.log(
            'Get links failed: {}'.format(response.status_code),
            xbmc.LOGERROR
        )
        return {}

    bs = BeautifulSoup(
        response.text,
        'html.parser'
    )

    videolink = {}

    index = 0

    for li in bs.select('div.movie-actions li'):

        a = li.find('a')

        if not a:
            continue

        href = a.get('href', '').strip()

        if not href:
            continue

        title = li.get('title', '').strip()

        if not title:

            span = a.find('span')

            if span:
                title = span.get_text(strip=True)

        if not title:
            title = 'Download'

        videolink[index] = {
            'name': title,
            'url': href
        }

        index += 1

    # Run requests in parallel
    with ThreadPoolExecutor(max_workers=10) as executor: #TODO: Move hardcoded to top file
        futures = [
            executor.submit(fetch_fshare_info, index, current)
            for index, current in videolink.items()
        ]

        for future in as_completed(futures):
            index, result = future.result()

            if result:
                videolink[index].update(result)

    return videolink

def list_links(post_id):
    """
    Create download link list in Kodi interface.

    :param post_id: Movie post id
    :type post_id: str
    """

    videolink = get_links(post_id)

    for v in videolink.values():

        size = v.get('current.size', 0)

        size_mb = round(size / 1024 / 1024)

        label = '{} [{} MB]'.format(
            v['name'],
            size_mb
        )

        list_item = xbmcgui.ListItem(
            label=label
        )

        item_type = v.get('current.type', 0)
        is_folder = True

        linkcode = get_fshare_linkcode(
            v['url']
        )

        url = get_url(
            action='play_fshare',
            linkcode=linkcode
        )

        if item_type == 1:

            info_tag = list_item.getVideoInfoTag()

            info_tag.setTitle(
                label
            )

            list_item.setProperty(
                'IsPlayable',
                'true'
            )

            is_folder = False
        else:
            url = get_url(
                action='listing',
                fshare=linkcode
            )

        xbmcplugin.addDirectoryItem(
            handle=_handle,
            url=url,
            listitem=list_item,
            isFolder=is_folder
        )

    xbmcplugin.endOfDirectory(
        _handle
    )

def get_fshare_links(linkcode):
    """
    Get file list from Fshare folder API.
    """

    if not linkcode:
        return []

    try:

        data = call_fshare_folder_api(linkcode)

        return data.get('items', [])

    except Exception as e:

        addon_log.log(
            'Fshare API error: {}'.format(e),
            xbmc.LOGERROR
        )

        return []

def list_fshare_links(linkcode):
    """
    List Fshare folder contents.
    """

    items = get_fshare_links(linkcode)

    for item in items:

        size = item.get('size', 0)

        size_mb = round(size / 1024 / 1024)

        label = '{} [{} MB]'.format(
            item.get('name', 'Unknown'),
            size_mb
        )

        list_item = xbmcgui.ListItem(
            label=label
        )

        item_type = item.get('type', 0)

        is_folder = True

        item_linkcode = item.get('linkcode', '')

        # File
        if item_type == 1:

            info_tag = list_item.getVideoInfoTag()

            info_tag.setTitle(
                label
            )

            list_item.setProperty(
                'IsPlayable',
                'true'
            )

            is_folder = False

            item_url = get_url(
                action='play_fshare',
                linkcode=item_linkcode
            )

        # Folder
        else:
            item_url = get_url(
                action='listing',
                fshare=item_linkcode
            )

        xbmcplugin.addDirectoryItem(
            handle=_handle,
            url=item_url,
            listitem=list_item,
            isFolder=is_folder
        )

    xbmcplugin.endOfDirectory(
        _handle
    )

def fshare_login():
    """
    Login Fshare account and save session.

    :return: Token and session id
    :rtype: tuple
    """

    username = addon.getSetting(
        'username'
    ).strip()

    password = addon.getSetting(
        'password'
    ).strip()

    if not username or not password:

        raise Exception(
            'Missing Fshare account'
        )

    response = requests.post(
        'https://api.fshare.vn/api/user/login',
        headers={
            'User-Agent': UA_FSHARE_API
        },
        json={
            'user_email': username,
            'password': password,
            'app_key': APP_KEY_FSHARE_API
        },
        timeout=10
    )

    data = response.json()

    if response.status_code != 200:

        raise Exception(
            data.get(
                'msg',
                'Login failed'
            )
        )

    token = data.get(
        'token',
        ''
    )

    session_id = data.get(
        'session_id',
        ''
    )

    if not token or not session_id:

        raise Exception(
            'Invalid Fshare session'
        )

    addon.setSetting(
        'fshare_token',
        token
    )

    addon.setSetting(
        'fshare_session_id',
        session_id
    )

    return token, session_id

def save_fshare_session(token, session_id):
    """
    Save Fshare session data.

    :param token: Fshare token
    :type token: str

    :param session_id: Fshare session id
    :type session_id: str
    """

    addon.setSetting(
        'fshare_token',
        token
    )

    addon.setSetting(
        'fshare_session_id',
        session_id
    )

def get_fshare_session():
    """
    Get saved Fshare session.

    :return: Token and session id
    :rtype: tuple
    """

    token = addon.getSetting(
        'fshare_token'
    ).strip()

    session_id = addon.getSetting(
        'fshare_session_id'
    ).strip()

    return token, session_id

def get_fshare_account_info():
    """
    Get Fshare account info.
    """

    session_id = addon.getSetting(
        'fshare_session_id'
    ).strip()

    if not session_id:
        raise Exception(
            'Missing Fshare session_id'
        )

    response = requests.get(
        'https://api.fshare.vn/api/user/get',
        headers={
            'Accept': 'application/json',
            'User-Agent': UA_FSHARE_API,
            'Cookie': f'session_id={session_id}'
        },
        timeout=10
    )

    data = response.json()

    addon_log.log(
        'Fshare account loaded',
        xbmc.LOGINFO
    )

    # xbmc.log(
    #     'FSHARE ACCOUNT INFO: {}'.format(
    #         json.dumps(
    #             data,
    #             ensure_ascii=False
    #         )
    #     ),
    #     xbmc.LOGINFO
    # )

    if response.status_code != 200:
        raise Exception(
            data.get('msg', 'Cannot get account info')
        )

    return data

def get_fshare_download_url(linkcode):
    """
    Get direct download url from Fshare API.

    :param linkcode: Fshare file linkcode
    :type linkcode: str

    :return: Direct video url
    :rtype: str
    """

    token, session_id = get_fshare_session()

    if not token or not session_id:
        token, session_id = fshare_login()

    file_url = 'https://www.fshare.vn/file/{}'.format(
        linkcode
    )

    response = requests.post(
        'https://api.fshare.vn/api/session/download',
        headers={
            'Accept': 'application/json',
            'User-Agent': UA_FSHARE_API,
            'Cookie': f'session_id={session_id}'
        },
        json={
            'url': file_url,
            'password': '',
            'token': token,
            'zipflag': 0
        },
        timeout=15
    )

    # Session expired
    if response.status_code == 201:

        addon_log.log(
            'Fshare session expired. Re-login...',
            xbmc.LOGWARNING
        )

        token, session_id = login_fshare()

        # Retry request
        response = requests.post(
            'https://api.fshare.vn/api/session/download',
            headers={
                'Accept': 'application/json',
                'User-Agent': UA_FSHARE_API,
                'Cookie': 'session_id={}'.format(session_id)
            },
            json={
                'url': file_url,
                'password': '',
                'token': token,
                'zipflag': 0
            },
            timeout=15
        )

    data = response.json()

    download_url = data.get('location')

    if not download_url:
        raise Exception(
            data.get('msg', 'Cannot get download url')
        )

    return download_url

def play_fshare(linkcode):
    """
    Play Fshare file.
    """

    try:

        stream_url = get_fshare_download_url(
            linkcode
        )

        play_item = xbmcgui.ListItem(
            path=stream_url
        )

        xbmcplugin.setResolvedUrl(
            _handle,
            True,
            listitem=play_item
        )

    except Exception as e:

        xbmcgui.Dialog().ok(
            'ThuVienCine',
            'Play failed:\n{}'.format(e)
        )

        xbmcplugin.setResolvedUrl(
            _handle,
            False,
            xbmcgui.ListItem()
        )

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            if 'category' in params:
                category = params.get('category', '/')
                page = int(params.get('page', '1'))
                query = params.get('query', '')
                list_videos(category, page, query)
            # Movie links
            elif 'video' in params:
                post_id = params.get('video')
                list_links(post_id)
            # Fshare folder
            elif 'fshare' in params:
                linkcode = params.get('fshare', '')
                list_fshare_links(linkcode)
        elif params['action'] == 'play_fshare':
            linkcode = params.get('linkcode', '')
            play_fshare(linkcode)
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    if not ensure_fshare_settings():
        xbmcgui.Dialog().ok(
            'ThuVienCine',
            'Bạn phải nhập tài khoản Fshare'
        )
    else:
        router(sys.argv[2][1:])