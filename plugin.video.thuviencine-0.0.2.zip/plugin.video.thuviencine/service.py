# -*- coding: utf-8 -*-

import os
import requests
import xbmc
import xbmcaddon
import xbmcvfs
from bs4 import BeautifulSoup


addon = xbmcaddon.Addon()

APP_ID = 'plugin.video.thuviencine'

DEFAULT_HOME_PAGE = ''

VERSION_URL = (
    'https://thuviencine.github.io/version.json'
)

UA = (
    'Mozilla/5.0 (X11; Linux x86_64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/59.0.3071.109 Safari/537.36'
)

HEADERS = {
    'User-Agent': UA
}

current_version = addon.getAddonInfo(
    'version'
)

xbmc.log(
    f'[{APP_ID}] Service started',
    xbmc.LOGINFO
)


def addon_log(message, level=xbmc.LOGINFO):
    """
    Write addon log.
    """

    xbmc.log(
        f'[{APP_ID}] {message}',
        level
    )


def version_tuple(version):
    """
    Convert version string to tuple.
    """

    return tuple(
        map(int, version.split('.'))
    )


def download_file(url, path):
    """
    Download file from URL.
    """

    response = requests.get(
        url,
        headers=HEADERS,
        stream=True,
        timeout=30
    )

    response.raise_for_status()

    with open(path, 'wb') as f:

        for chunk in response.iter_content(
            1024 * 64
        ):

            if chunk:
                f.write(chunk)


def install_update(zip_url):
    """
    Download and install addon update.
    """

    packages_dir = xbmcvfs.translatePath(
        'special://home/addons/packages/'
    )

    if not os.path.exists(packages_dir):
        os.makedirs(packages_dir)

    zip_path = os.path.join(
        packages_dir,
        '{}.update.zip'.format(APP_ID)
    )

    addon_log(
        'Downloading addon update'
    )

    download_file(
        zip_url,
        zip_path
    )

    addon_log(
        'Installing addon update'
    )

    xbmc.executebuiltin(
        'InstallAddon({})'.format(
            zip_path
        )
    )


def check_addon_update():
    """
    Check and update addon.
    """

    try:

        addon_log(
            'Checking addon update'
        )

        response = requests.get(
            VERSION_URL,
            headers=HEADERS,
            timeout=10
        )

        response.raise_for_status()

        data = response.json()

        latest_version = data.get(
            'version',
            ''
        ).strip()

        zip_url = data.get(
            'zip',
            ''
        ).strip()

        if not latest_version:

            addon_log(
                'Missing latest version',
                xbmc.LOGWARNING
            )

            return

        if not zip_url:

            addon_log(
                'Missing zip URL',
                xbmc.LOGWARNING
            )

            return

        addon_log(
            'Current version: {}'.format(
                current_version
            )
        )

        addon_log(
            'Latest version: {}'.format(
                latest_version
            )
        )

        if (
            version_tuple(latest_version)
            <= version_tuple(current_version)
        ):

            addon_log(
                'Addon already up to date'
            )

            return

        addon_log(
            'New addon update detected'
        )

        install_update(zip_url)

    except Exception as e:

        addon_log(
            'Addon update exception: {}'.format(
                e
            ),
            xbmc.LOGERROR
        )


def update_home_page():
    """
    Update home page from GitHub Pages.
    """

    repo_url = 'https://thuviencine.github.io/'

    try:

        response = requests.get(
            repo_url,
            headers=HEADERS,
            timeout=10
        )

        if response.status_code != 200:

            addon_log(
                'Update domain failed: {}'.format(
                    response.status_code
                ),
                xbmc.LOGWARNING
            )

            return

        soup = BeautifulSoup(
            response.text,
            'html.parser'
        )

        domain_tag = soup.find(
            'span',
            id='default-home-page'
        )

        if not domain_tag:

            addon_log(
                'Default home page tag not found',
                xbmc.LOGWARNING
            )

            return

        new_domain = domain_tag.get_text(
            strip=True
        ).rstrip('/')

        if not new_domain.startswith('http'):

            addon_log(
                'Invalid domain format',
                xbmc.LOGWARNING
            )

            return

        current_domain = addon.getSetting(
            'default_home_page'
        ).strip().rstrip('/')

        if not current_domain:
            current_domain = DEFAULT_HOME_PAGE

        if current_domain != new_domain:

            addon.setSetting(
                'default_home_page',
                new_domain
            )

            addon_log(
                'Domain updated: {}'.format(
                    new_domain
                )
            )

        else:

            addon_log(
                'Domain unchanged: {}'.format(
                    current_domain
                )
            )

    except Exception as e:

        addon_log(
            'Update domain exception: {}'.format(
                e
            ),
            xbmc.LOGERROR
        )


def startup_task():
    """
    Run startup tasks.
    """

    addon_log(
        'Running startup task'
    )

    # Update domain
    update_home_page()

    # Update addon
    check_addon_update()


startup_task()