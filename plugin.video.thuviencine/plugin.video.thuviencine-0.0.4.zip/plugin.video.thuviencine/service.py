# -*- coding: utf-8 -*-

import os
import requests
import xbmc
import xbmcaddon
import xbmcvfs
from bs4 import BeautifulSoup


addon = xbmcaddon.Addon()

APP_ID = 'plugin.video.thuviencine'

DEFAULT_HOME_PAGE = ''

VERSION_URL = (
    'https://thuviencine.github.io/plugin.video.thuviencine/version.json'
)

UA = (
    'Mozilla/5.0 (X11; Linux x86_64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/59.0.3071.109 Safari/537.36'
)

HEADERS = {
    'User-Agent': UA
}

current_version = addon.getAddonInfo(
    'version'
)

xbmc.log(
    f'[{APP_ID}] Service started',
    xbmc.LOGINFO
)


def addon_log(message, level=xbmc.LOGINFO):
    """
    Write addon log.
    """

    xbmc.log(
        f'[{APP_ID}] {message}',
        level
    )


def update_home_page():
    """
    Update home page from GitHub Pages.
    """

    repo_url = 'https://thuviencine.github.io/'

    try:

        response = requests.get(
            repo_url,
            headers=HEADERS,
            timeout=10
        )

        if response.status_code != 200:

            addon_log(
                'Update domain failed: {}'.format(
                    response.status_code
                ),
                xbmc.LOGWARNING
            )

            return

        soup = BeautifulSoup(
            response.text,
            'html.parser'
        )

        domain_tag = soup.find(
            'span',
            id='default-home-page'
        )

        if not domain_tag:

            addon_log(
                'Default home page tag not found',
                xbmc.LOGWARNING
            )

            return

        new_domain = domain_tag.get_text(
            strip=True
        ).rstrip('/')

        if not new_domain.startswith('http'):

            addon_log(
                'Invalid domain format',
                xbmc.LOGWARNING
            )

            return

        current_domain = addon.getSetting(
            'default_home_page'
        ).strip().rstrip('/')

        if not current_domain:
            current_domain = DEFAULT_HOME_PAGE

        if current_domain != new_domain:

            addon.setSetting(
                'default_home_page',
                new_domain
            )

            addon_log(
                'Domain updated: {}'.format(
                    new_domain
                )
            )

        else:

            addon_log(
                'Domain unchanged: {}'.format(
                    current_domain
                )
            )

    except Exception as e:

        addon_log(
            'Update domain exception: {}'.format(
                e
            ),
            xbmc.LOGERROR
        )


def startup_task():
    """
    Run startup tasks.
    """

    addon_log(
        'Running startup task'
    )

    # Update domain
    update_home_page()

    # Update addon

startup_task()