# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()

APP_ID = 'plugin.video.thuviencine'

DEFAULT_HOME_PAGE = ''

CONFIG_URL = (
    'https://thuviencine.github.io/plugin.video.thuviencine/config.json'
)

UA = (
    'Mozilla/5.0 (X11; Linux x86_64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/59.0.3071.109 Safari/537.36'
)

HEADERS = {
    'User-Agent': UA
}

current_version = addon.getAddonInfo(
    'version'
)


def addon_log(message, level=xbmc.LOGINFO):
    """
    Write addon log.
    """

    xbmc.log(
        f'[{APP_ID}] {message}',
        level
    )


def update_home_page():
    """
    Update home page from config.json.
    """

    try:

        response = requests.get(
            CONFIG_URL,
            headers=HEADERS,
            timeout=10
        )

        response.raise_for_status()

        data = response.json()

        new_domain = data.get(
            'default_home_page',
            ''
        ).strip().rstrip('/')

        if not new_domain.startswith('http'):

            addon_log(
                'Invalid domain format',
                xbmc.LOGWARNING
            )

            return

        current_domain = addon.getSetting(
            'default_home_page'
        ).strip().rstrip('/')

        if not current_domain:
            current_domain = DEFAULT_HOME_PAGE

        if current_domain == new_domain:
            return

        addon.setSetting(
            'default_home_page',
            new_domain
        )

        addon_log(
            'Domain updated: {}'.format(
                new_domain
            )
        )

    except Exception as e:

        addon_log(
            'Update domain exception: {}'.format(
                e
            ),
            xbmc.LOGERROR
        )


def startup_task():
    """
    Run startup tasks.
    """

    # Update domain
    update_home_page()

    # Update addon

startup_task()